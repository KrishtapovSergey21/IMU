const UNIQUE_CODE_SIZE = 4;
const UNIQUE_CODE_INDEX = 2;
const CODE_BASE_SIZE = 2;
const COMMAND_CODE_INDEX = 6;
const DEVICE_DATA_START_INDEX = 7;

let NOT_CONTAIN_ACC_CONFIG = {
    "commandCode": "84",
    "dataBits": [
        {
            "dataSize": 8,
            "base": 16,
            "dataName": "x-ang",
            "containSignBit": true,
            "integerBit": 3,
            "decimalPlaces": 4
        },
        {
            "dataSize": 8,
            "base": 16,
            "dataName": "y-ang",
            "containSignBit": true,
            "integerBit": 3,
            "decimalPlaces": 4
        },
        {
            "dataSize": 6,
            "base": 16,
            "dataName": "temp",
            "containSignBit": true,
            "integerBit": 3,
            "decimalPlaces": 2
        },
        {
            "dataSize": 2,
            "base": 16,
            "dataName": "elect",
            "containSignBit": false,
            "integerBit": 2
        }
    ]
};

let CONTAIN_ACC_CONFIG = {
    "commandCode": "83",
    "dataBits": [
        {
            "dataSize": 8,
            "base": 16,
            "dataName": "x-ang",
            "containSignBit": true,
            "integerBit": 3,
            "decimalPlaces": 4
        },
        {
            "dataSize": 8,
            "base": 16,
            "dataName": "y-ang",
            "containSignBit": true,
            "integerBit": 3,
            "decimalPlaces": 4
        },
        {
            "dataSize": 8,
            "base": 16,
            "dataName": "z-ang",
            "containSignBit": true,
            "integerBit": 3,
            "decimalPlaces": 4
        },
        {
            "dataSize": 8,
            "base": 16,
            "dataName": "x-acc",
            "containSignBit": true,
            "integerBit": 1,
            "decimalPlaces": 6
        },
        {
            "dataSize": 8,
            "base": 16,
            "dataName": "y-acc",
            "containSignBit": true,
            "integerBit": 1,
            "decimalPlaces": 6
        },
        {
            "dataSize": 8,
            "dataOrder": 3,
            "base": 16,
            "dataName": "z-acc",
            "containSignBit": true,
            "integerBit": 1,
            "decimalPlaces": 6
        },
        {
            "dataSize": 6,
            "dataOrder": 3,
            "base": 16,
            "dataName": "temp",
            "containSignBit": true,
            "integerBit": 3,
            "decimalPlaces": 2
        },
        {
            "dataSize": 2,
            "dataOrder": 4,
            "base": 16,
            "dataName": "elect",
            "containSignBit": false,
            "integerBit": 2
        }
    ]
};

class BaseBit {
    constructor(dataSize, base, unit, dataName) {
        this.dataSize = dataSize;
        this.base = base;
        this.dataName = dataName;
    }
}

class DataBit extends BaseBit {
    constructor(dataSize, base, unit, dataName, containSignBit, integerBit, decimalPlaces) {
        super(dataSize, base, unit, dataName);
        this.containSignBit = containSignBit;
        this.integerBit = integerBit;
        this.decimalPlaces = decimalPlaces;
    }

    dataHandle(data) {
        let symbol = 0;
        let result;
        if (this.containSignBit) {
            symbol = parseInt(data.substring(0, 1));
            data = data.substring(1);
        }
        let integerValue = data.substring(0, this.integerBit);
        if (this.decimalPlaces !== undefined) {
            let endIndex = parseInt(this.integerBit + this.decimalPlaces);
            let decimalValue = data.substring(this.integerBit, endIndex);
            result = parseFloat(integerValue + '.' + decimalValue);
        } else {
            result = parseInt(integerValue);
        }
        if (symbol !== 0) {
            result = 0 - result;
        }
        return result;
    }
}

class DataModel {
    constructor(commandCode, dataBits) {
        this.commandCode = commandCode;
        this.dataBits = dataBits;
    }

    decodeDevicePayload(deviceData) {
        let splitData = this.splitDeviceMessageByDataSize(deviceData);
        let analyseJson = {};
        for (let itemIndex = 0; itemIndex < this.dataBits.length; itemIndex++) {
            let dataItem = copy(this.dataBits[itemIndex], new DataBit());
            let dataName = dataItem.dataName;
            analyseJson[dataName] = dataItem.dataHandle(splitData[itemIndex]);
        }
        return analyseJson;
    }

    splitDeviceMessageByDataSize(deviceData) {
        let codeFormat = [];
        let splitDataCollect = [];
        for (let index = 0; index < this.dataBits.length; index++) {
            codeFormat.push(this.dataBits[index].dataSize);
        }
        const toNoNullData = deviceData.replace(/\s+/g, '');
        let index = 0;
        for (let i = 0; i < codeFormat.length; i++) {
            let endIndex = parseInt(index + codeFormat[i]);
            const dataBitData = toNoNullData.substring(index, endIndex);
            splitDataCollect.push(dataBitData);
            index = endIndex;
        }
        return splitDataCollect;
    }
}

let NOT_CONTAIN_ACC_MODEL = copy(NOT_CONTAIN_ACC_CONFIG, new DataModel());
let CONTAIN_ACC_MODEL = copy(CONTAIN_ACC_CONFIG, new DataModel());

function hexToBytes(hex) {
    const fixData = hex.replace(/\s+/g, '');
    let bytes = [];
    for (let c = 0; c < fixData.length; c += CODE_BASE_SIZE)
        bytes.push(parseInt(fixData.substr(c, CODE_BASE_SIZE), 16));
    return bytes;
}

function DecodeDevicePayload(data) {
    let obj = {};
    if (DeviceMessageLegalValid(data)) {
        let unicode = UniqueCodeHandle(data);
        switch (GetDeviceMessageHandleModel(data)) {
            case NOT_CONTAIN_ACC_MODEL.commandCode:
                obj = NOT_CONTAIN_ACC_MODEL.decodeDevicePayload(GetDeviceMessage(data));
                break;
            case CONTAIN_ACC_MODEL.commandCode:
                obj = CONTAIN_ACC_MODEL.decodeDevicePayload(GetDeviceMessage(data));
                break;
        }
        obj.unicode = unicode;
        return obj;
    } else {
        return {};
    }
}

function copy(origin, target) {
    let targetProto = Object.getPrototypeOf(target);
    return Object.assign(Object.create(targetProto), origin);
}

function UniqueCodeHandle(data) {
    const endSize = UNIQUE_CODE_INDEX + UNIQUE_CODE_SIZE;
    let uniqueCode = '';
    for (let index = UNIQUE_CODE_INDEX; index < endSize; index++) {
        uniqueCode += data[index].toString(16).padStart(2, '0');
    }
    return uniqueCode;
}

function GetDeviceMessageHandleModel(data) {
    return data[COMMAND_CODE_INDEX].toString(16);
}

function GetDeviceMessage(data) {
    let deviceMessage = '';
    for (let index = DEVICE_DATA_START_INDEX; index < data.length - 1; index++) {
        deviceMessage += data[index].toString(16).padStart(2, '0');
    }
    return deviceMessage;
}

function DeviceMessageLegalValid(data) {
    if (data instanceof Array) {
        const dataSize = data[1];
        if ((dataSize + 1) === data.length) {
            let totalCount = 0;
            for (let index = 1; index < data.length - 1; index++) {
                totalCount += data[index];
            }
            const expectResult = data[data.length - 1].toString(16);
            const result = totalCount.toString(16).slice(-2);
            if (expectResult === result) {
                return true;
            }
        }
    }
    return false;
}

// ChirpStack required decode function
function decodeUplink(input) {
    const bytes = input.bytes;
    const data = DecodeDevicePayload(bytes);
    return {
        data: data
    };
}

// ChirpStack required encode function (optional if needed for downlinks)
function encodeDownlink(input) {
    const data = input.data;
    // Implement encoding logic if necessary
    return {
        bytes: [] // replace with actual bytes array
    };
}

