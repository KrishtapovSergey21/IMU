
#ifndef __HAL_H
#define __HAL_H

#include "stm32l4xx_hal.h"
#define HAL_431 431

#endif /* __HAL_H */
