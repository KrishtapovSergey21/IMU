/*******************************************************
 * @file rtk.cpp
 * @author khshen (khshen@aceinna.com)
 * @brief 
 * @date 2021-06-10
 * 
 * @copyright Copyright (c) 2021
 * 
*******************************************************/
#include "rtk.h"

CRTK::CRTK()
{
    cout << "CRTK:CRTK()" << endl;
}

CRTK::~CRTK()
{
    cout << "CRTK:~CRTK()" << endl;
}
