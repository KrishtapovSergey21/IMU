# OpenLink
Openlink is a tool for forwarding stream. OpenLink can input data from any channel of network, serial port and file, and output data from any channel of network, serial port and file. It supports reading RTCM and ublox files and sending them to other streams. It can also be used to modify the position information in RTCM.
