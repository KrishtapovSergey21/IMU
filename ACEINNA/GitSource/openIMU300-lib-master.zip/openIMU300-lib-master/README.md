# openIMU-300 Platform Library
OpenIMU300 Platform Library v1.0.10
