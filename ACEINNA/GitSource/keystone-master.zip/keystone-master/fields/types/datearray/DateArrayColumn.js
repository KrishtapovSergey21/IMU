module.exports = require('../../components/columns/ArrayColumn');
