module.exports = {
	Field: require('../GeoPointField'),
	Filter: require('../GeoPointFilter'),
	section: 'Miscellaneous',
	spec: {
		label: 'Geopoint',
		path: 'geopoint',
		value: [],
	},
};
