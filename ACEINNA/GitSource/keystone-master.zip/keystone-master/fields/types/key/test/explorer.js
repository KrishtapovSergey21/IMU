module.exports = {
	Field: require('../KeyField'),
	Filter: require('../KeyFilter'),
	section: 'Text',
	spec: {
		label: 'Key',
		path: 'key',
		value: 'keystone',
	},
};
