# LocalFiles

> Warning: the LocalFiles Field has been deprecated. Please use the [File](/api/field/File) and a storage adapter going forward.
