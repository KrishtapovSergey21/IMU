module.exports = require('../cloudinaryimage/CloudinaryImageFilter');
