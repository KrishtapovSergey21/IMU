module.exports = require('../text/TextColumn');
