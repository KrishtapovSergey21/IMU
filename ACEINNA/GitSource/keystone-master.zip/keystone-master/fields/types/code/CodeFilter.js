module.exports = require('../text/TextFilter');
