exports.createDynamicRouter = require('./app/createDynamicRouter');
exports.createStaticRouter = require('./app/createStaticRouter');
