export const SELECT_ITEM = 'app/Item/SELECT_ITEM';
export const LOAD_DATA = 'app/Item/LOAD_DATA';
export const DATA_LOADING_SUCCESS = 'app/Item/DATA_LOADING_SUCCESS';
export const DATA_LOADING_ERROR = 'app/Item/DATA_LOADING_ERROR';
export const DRAG_MOVE_ITEM = 'app/Item/DRAG_MOVE_ITEM';
export const DRAG_RESET_ITEMS = 'app/Item/DRAG_RESET_ITEMS';
export const LOAD_RELATIONSHIP_DATA = 'app/Item/LOAD_RELATIONSHIP_DATA';
