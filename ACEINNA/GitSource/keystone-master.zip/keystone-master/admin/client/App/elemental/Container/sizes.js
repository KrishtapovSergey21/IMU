import theme from '../../../theme';

module.exports = {
	small: theme.container.size.small,
	medium: theme.container.size.medium,
	large: theme.container.size.large,
};
