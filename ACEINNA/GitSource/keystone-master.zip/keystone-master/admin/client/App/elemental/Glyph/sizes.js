import theme from '../../../theme';

module.exports = {
	small: theme.glyph.size.small,
	medium: theme.glyph.size.medium,
	large: theme.glyph.size.large,
};
