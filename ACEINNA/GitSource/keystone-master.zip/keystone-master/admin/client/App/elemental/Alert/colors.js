import theme from '../../../theme';

module.exports = {
	danger: theme.alert.color.danger,
	error: theme.alert.color.danger,
	info: theme.alert.color.info,
	success: theme.alert.color.success,
	warning: theme.alert.color.warning,
};
