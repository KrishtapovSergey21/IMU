module.exports = ['danger', 'default', 'inverted', 'primary', 'success', 'warning'];
