import Body from './body';
import Dialog from './dialog';
import Footer from './footer';
import Header from './header';

export {
	Body,
	Dialog,
	Footer,
	Header,
};
