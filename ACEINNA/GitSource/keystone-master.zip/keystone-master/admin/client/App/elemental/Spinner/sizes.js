module.exports = ['small', 'medium', 'large'];
