# Close Database connection

## `keystone.closeDatabaseConnection(callback:Function)`

Closes all database connections Keystone has open.
