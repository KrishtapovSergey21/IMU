# Pre

## `keystone.pre(actionName:String, desiredAction:Function)`

Pre can be used to add some of the global middleware that Keystone can add. Most specifically, any with the `pre` prefix. For more information about adding middleware, see the [middleware documentation](/api/methods/middleware).
