# Create Router

## `var newRouter = keystone.createRouter()`

Returns a new [express router](https://expressjs.com/en/4x/api.html#router) object.
