# API References

## Most Common Locations

- [List](/api/list)
- [Methods](/api/methods/close-database-connection)
- [View](/api/view/on)
- [Field Types](/api/field/options)
