# Package Version
VERSION = '2.6.12'
PACKAGE_NAME = 'acenav'
