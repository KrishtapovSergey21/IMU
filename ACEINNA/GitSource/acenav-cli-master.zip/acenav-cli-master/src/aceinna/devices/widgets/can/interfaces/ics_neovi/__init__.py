# coding: utf-8

"""
"""

from can.interfaces.ics_neovi.neovi_bus import NeoViBus
