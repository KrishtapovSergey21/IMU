OpenRTK as Base Station
=======================

.. image:: media/clipboard.png
   :align: center

Connect openrtk module and serial port, 'input' select serial port, fill in the parameters.