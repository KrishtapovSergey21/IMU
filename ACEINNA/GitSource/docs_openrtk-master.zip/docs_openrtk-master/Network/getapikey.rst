API key Generation
==================

1. Login developers website. https://developers.aceinna.com/

 .. image:: ../media/ntrip_1.png

2. Generate and get password.

 .. image:: ../media/ntrip_2.png
 .. image:: ../media/ntrip_3.png
 .. image:: ../media/ntrip_4.png
 .. image:: ../media/ntrip_5.png
 .. image:: ../media/ntrip_6.png
 .. image:: ../media/ntrip_7.png
