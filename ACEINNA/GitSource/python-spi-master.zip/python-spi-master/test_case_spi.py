'''
creat test cases for UUT based on dev_spi and OpenIMU_SPI
record parameters of UUT, do some operations related with HW unit.
v1.0 20210423 erkuo chen
'''







