<!--- Provide a general summary of the issue in the Title above -->

## Your Environments
- mongoosastic version: x.y.z
- node version: x.y.z
- mongoose version: x.y.z
- elasticsearch version: x.y.z

## Expected Behavior
<!--- Tell us what should happen -->

## Actual Behavior
<!--- Tell us what happens instead -->

## Error Stack
<!-- Tell us error stack if you have -->
