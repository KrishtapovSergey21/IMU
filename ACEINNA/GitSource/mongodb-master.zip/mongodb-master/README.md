1)npm install <br>
2)put mongodb to connectstring in server.js <br>
3)node server.js <br>
3)http://localhost:3000/ you will see up to 100 records for GNSS data gaps <br>
