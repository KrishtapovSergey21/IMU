Simple GUI for supporting OpenIMU300ZI serial interface messages
