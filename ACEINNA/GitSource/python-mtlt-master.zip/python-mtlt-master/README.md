# python-mtlt
CAN bus Drivers for dynamic tilt MTLT and OpenIMU300RI (J1939 app) inertial measurement unit, using PyCan and Pi3
