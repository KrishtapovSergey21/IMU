# Package Version
VERSION = '2.7.0'
PACKAGE_NAME = 'openimu'
