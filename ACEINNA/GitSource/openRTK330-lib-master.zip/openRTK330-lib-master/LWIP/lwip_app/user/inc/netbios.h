#ifndef __NETBIOS_H__
#define __NETBIOS_H__

void netbios_init(void);

#define NETBIOS_LWIP_NAME "OPENRTK"

// #define USER_SN_WEB_NAME

#endif /* __NETBIOS_H__ */
