#ifndef __CRC16_H
#define __CRC16_H

uint16_t CalculateCRC (uint8_t *buf, uint16_t  length);

#endif
