#ifndef _RNG_H_
#define _RNG_H_

#include <stdint.h>

void RNG_Init(void);

#endif
