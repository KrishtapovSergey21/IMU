/*******************************************************************************
* File Name          : exit.h
* Author             : Daich
* Revision           : 1.0
* Date               : 18/10/2019
* Description        : exit.h
*
* HISTORY***********************************************************************
* 18/10/2019  |                                             | Daich
* Description: create
*******************************************************************************/
#ifndef _EXIT_H_
#define _EXIT_H_
//#pragma once
void pps_exit_init(void);
extern uint8_t get_gnss_signal_flag();
void PULSE_IRQ();

#endif
