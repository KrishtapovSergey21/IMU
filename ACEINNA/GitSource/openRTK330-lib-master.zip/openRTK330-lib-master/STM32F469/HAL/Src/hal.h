
#ifndef __HAL_H
#define __HAL_H

#include "stm32f4xx_hal.h"
#define HAL_431 431

#endif /* __HAL_H */
