*******************************
Innovation / Measurement Error
*******************************

.. toctree::
    :maxdepth: 4

.. sectionauthor:: Joseph S Motyka <jmotyka at aceinna.com>


Innovation Overview
===================

The innovation (measurement error) is formed from the sensor measurements and the predicted states.
As the measurements and the system states are often not the same, one or the other needs to be
transformed into the measurement.  In the case of this algorithm, the state consists of an attitude
quaternion, NED-velocity, and NED-position.  The measurement come from accelerometer readings, GPS
latitude/longitude/altitude measurements, and horizontal/vertical velocities along with
ground-track.  In this case either the states need to be converted to match the measurements or vice-versa.


Once the measurements vectors are formed, the innovation (measurement error), :math:`\vec{\nu}_{k}`,
is computed:

.. math::

    \vec{\nu}_{k} = \vec{z}_{k} - \vec{h}_{k}


This result is used in the update stage of the EKF to generate the state error,
:math:`{\Delta\vec{x}}_{k}`, given the Kalman gain matrix.



.. state environment of the system  and uses the available sensor information as follows:

The available sensor information is used as follows:


    #. Accelerometers “level” the system (used to compute :math:`{^{\perp}}{\phi}{_{meas}^{B}}` and
       :math:`{^{\perp}}{\theta}{_{meas}^{B}}`) FN

    #. Magnetometers and/or GPS heading information align the \perp-frame with true or magnetic north
       (:math:`{^{N}}{\psi}{^{\perp}}`)

    #. GPS position and velocity measurements update the position and velocity estimates
       (:math:`\vec{r}^{N}` and :math:`\vec{v}^{N}`)



Measurement Details To Be Provided
