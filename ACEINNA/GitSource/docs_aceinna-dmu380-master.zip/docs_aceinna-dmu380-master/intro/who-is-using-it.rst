
Who is using it?
================

The OpenIMU project is recommended for **autonomous system** developers with challenging navigation and localization requirements.  
The system is being used by several autonomous driving teams globally.

.. contents:: Contents
    :local:

