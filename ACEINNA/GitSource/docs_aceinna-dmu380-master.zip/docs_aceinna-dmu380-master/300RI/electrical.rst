Electrical,  and Physical Specifications
=========================================

.. contents:: Contents
    :local:


.. include:: <isonum.txt>

.. image:: ../media/OpenIMU300RI-Specifications.png
    :height: 425
