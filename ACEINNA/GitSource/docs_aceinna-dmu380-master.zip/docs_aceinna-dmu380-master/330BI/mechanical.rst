OpenIMU330BI EVB Schematic
==========================

.. image:: ../media/6310-6000-03_Rev.A.png

Schematic :download:`download <../media/6310-6000-03_Rev.A.PDF>`
