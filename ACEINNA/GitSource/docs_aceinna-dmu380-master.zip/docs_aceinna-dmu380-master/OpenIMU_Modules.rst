OpenIMU Modules
===============
.. contents:: Contents
    :local:

The four OpenIMU modules that are currently available are the:

.. toctree::
    :maxdepth: 1

    300ZI
    300RI
    330BI
    335RI

.. toctree::
    :maxdepth: 1
    :hidden:
    