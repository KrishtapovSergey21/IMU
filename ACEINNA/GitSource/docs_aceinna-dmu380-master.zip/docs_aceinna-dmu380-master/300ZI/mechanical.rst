OpenIMU300ZI EVK Mechanical Drawing
===================================

.. contents:: Contents
    :local:

.. image:: ../media/8550-3885-01_EvalKit_OpenIMU300ZI.png


.. note:: Use the browser's back button to return to this page.


Mechanical Drawing :download:`download link <../media/8550-3885-01_EvalKit_OpenIMU300ZI.PDF>`
