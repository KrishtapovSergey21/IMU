TODO - Impementing algorithms based on :

# Cut points
* P. S. Freedson, E. Melanson, and J. Sirard. Calibration of the computer science and applications, inc. accelerometer. Medicine and science in sports and exercise, 30(5):777–781, May 1998.
* Freedson PS, Pober D, Janz KF. Calibration of accelerometer output for children. Med Sci Sports Exerc. 2005;37(11 suppl): S523–30
* [Jeffer E. Sasaki, Dinesh John, Patty S. Freedson,
Validation and comparison of ActiGraph activity monitors,
Journal of Science and Medicine in Sport, Volume 14, Issue 5, 2011, Pages 411-416, ISSN 1440-2440.](https://www.sciencedirect.com/science/article/pii/S1440244011000788)
* [Puyau, M. R., Adolph, A. L., Vohra, F. A. and Butte, N. F. (2002), Validation and Calibration of Physical Activity Monitors in Children. Obesity Research, 10: 150–157. doi:10.1038/oby.2002.24](http://onlinelibrary.wiley.com/doi/10.1038/oby.2002.24/full)
