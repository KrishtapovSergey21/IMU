from libopenimu.importers.importer_types import ImporterTypes


class StreamerTypes:
    APPLEWATCH = 0

    value_types = [APPLEWATCH]
    value_names = ['AppleWatch']
    value_importer_types = [ImporterTypes.APPLEWATCH]
