"""

    Unit testing for Calibration
    @authors Simon Brière, Dominic Létourneau
    @date 03/04/2018

"""

