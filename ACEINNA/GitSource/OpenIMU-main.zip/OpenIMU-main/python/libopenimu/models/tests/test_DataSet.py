"""

    Unit testing for DataSet
    @authors Simon Brière, Dominic Létourneau
    @date 03/04/2018

"""
