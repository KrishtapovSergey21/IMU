"""

    Unit testing for SensorTimestamps
    @authors Simon Brière, Dominic Létourneau
    @date 10/10/2018

"""


import unittest


class UnitsTest(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass
