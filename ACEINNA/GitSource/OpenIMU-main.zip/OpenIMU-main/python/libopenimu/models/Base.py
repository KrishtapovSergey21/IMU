from sqlalchemy.ext.declarative import declarative_base

# Declarative Base class definition
Base = declarative_base()

