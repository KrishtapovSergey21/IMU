"""
 Calibration
 @authors Simon Brière, Dominic Létourneau
 @date 02/04/2018
"""


class Calibration:
    def __init__(self):
        return
