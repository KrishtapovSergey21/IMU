"""

    Unit testing for import to DB
    @authors Simon Brière, Dominic Létourneau
    @date 25/04/2018

"""
import unittest


class IMUChartViewTest(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

