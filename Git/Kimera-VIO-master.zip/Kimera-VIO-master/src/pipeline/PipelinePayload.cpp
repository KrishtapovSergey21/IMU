#include "kimera-vio/pipeline/PipelinePayload.h"

namespace VIO {

PipelinePayload::PipelinePayload(const Timestamp& timestamp)
    : timestamp_(timestamp){};

}  // namespace VIO
