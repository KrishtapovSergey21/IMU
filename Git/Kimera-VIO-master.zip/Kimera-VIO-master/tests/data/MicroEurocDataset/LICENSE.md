Dataset belongs to ASL/ETHZ: https://projects.asl.ethz.ch/datasets/doku.php?id=kmavvisualinertialdatasets
