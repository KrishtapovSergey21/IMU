# ROS install
pip install --extra-index-url https://rospypi.github.io/simple/ nav_msgs visualization_msgs std_srvs
cp ~/Code/pepper_ws/devel/lib/python2.7/dist-packages/spencer_tracking_msgs ~/pepper3venv/lib/python3.6/site-packages/ -r

# to source
# source ~/Code/pepper_ws/devel/setup.bash
# source ~/pepper3venv/bin/activate
# cd ~/Code/navrep



